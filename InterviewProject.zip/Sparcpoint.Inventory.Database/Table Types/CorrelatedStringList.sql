﻿CREATE TYPE [dbo].[CorrelatedStringList] AS TABLE
(
	[Index] INT NOT NULL,
	[Value] VARCHAR(512) NOT NULL
)
